let userScore = 0;
let compScore = 0;

const choices = document.querySelectorAll(".choice");
const msg = document.querySelector("#msg");

const userScorePara = document.querySelector("#user-score");
const compScorePara = document.querySelector("#comp-score");

const genComputerChoice = () => {
    //comp pick randomly from rock,paper,scissors
    const options = ["rock", "paper", "scissors"];
    const randIdx = Math.floor(Math.random() * 3);     //using Math.random computer automatically generate random value.
    return options[randIdx];
};

const drawGame =  () => {
       msg.innerText = "Game was draw. play again";
       msg.style.backgroundColor = "purple";
};

const showWinner = (userWin, userChoice, compChoice) => {
    if(userWin){
        userScore++;
        userScorePara.innerText = userScore;
        msg.innerText = `You Win! Your ${userChoice} beats ${compChoice}`;
        msg.style.backgroundColor = "green";
    } else {
        compScore++;
        compScorePara.innerText = compScore;
        msg.innerText = `You lost. ${compChoice} beats Your ${userChoice}`;
        msg.style.backgroundColor = "red";
    }
};

const playGame = (userChoice) => {
    console.log("user choice", userChoice);
    //Generate computer choice
    const compChoice = genComputerChoice();
    console.log("computer choice", compChoice);

    if(userChoice === compChoice){
        //Draw game
        drawGame();
    } else {
        let userWin = true;
        if(userChoice === "rock"){
            // comp choice will be either paper or scissors
            userWin = compChoice === "paper" ? false : true ; //if compchoice is paper then user loss comp win and if comp choice is scissor then user win
        } else if (userChoice === "paper") {
            //comp choice either rock and scissors
            userWin = compChoice === "scissors" ? false : true ;
        } else {
            //now userchoice remain scissors  so now comp have 2 choice either rock or paper
            userWin = compChoice === "rock" ? false : true;
        }
        showWinner(userWin, userChoice, compChoice);
    }
};

choices.forEach((choice) => {
    choice.addEventListener("click", () => {
        const userChoice = choice.getAttribute("id");
        playGame(userChoice);
    });
});